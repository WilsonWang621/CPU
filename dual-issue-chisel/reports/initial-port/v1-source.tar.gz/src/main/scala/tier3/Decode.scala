package tier3

import chisel3._
import chisel3.util._
import tier3.Bits._
import ISA._

class Decoder extends Logic {
  override def desiredName = "decoder"
  val inst = in(32); val dec = out((new Decoded).getWidth)
  val d = WireDefault(0.U.asTypeOf(new Decoded))
  val f3 = inst(14, 12); val f7 = inst(31, 25)
  d.op := ADD; d.rs1 := inst(19, 15); d.rs2 := inst(24, 20); d.rd := inst(11, 7)
  // Publish legality/x0 qualification only after all raw decode writes.
  val raw = WireDefault(0.U.asTypeOf(new Decoded))
  raw.op := ADD; raw.rs1 := inst(19, 15); raw.rs2 := inst(24, 20); raw.rd := inst(11, 7)
  switch(inst(6, 0)) {
    is("b0110111".U, "b0010111".U) {
      raw.op := Mux(inst(6, 0) === "b0110111".U, LUI, AUIPC)
      raw.imm := Cat(inst(31, 12), 0.U(12.W)); raw.writes_rd := true.B
    }
    is("b1101111".U) {
      raw.op := JAL; raw.imm := sext(Cat(inst(31), inst(19, 12), inst(20), inst(30, 21), 0.U(1.W)))
      raw.writes_rd := true.B
    }
    is("b1100111".U) {
      raw.op := JALR; raw.uses_rs1 := true.B; raw.writes_rd := true.B; raw.use_imm := true.B
      raw.imm := sext(inst(31, 20)); raw.illegal := f3 =/= 0.U
    }
    is("b1100011".U) {
      raw.uses_rs1 := true.B; raw.uses_rs2 := true.B
      raw.imm := sext(Cat(inst(31), inst(7), inst(30, 25), inst(11, 8), 0.U(1.W)))
      raw.op := MuxLookup(f3, ADD)(Seq(0.U -> BEQ, 1.U -> BNE, 4.U -> BLT, 5.U -> BGE, 6.U -> BLTU, 7.U -> BGEU))
      raw.illegal := f3 === 2.U || f3 === 3.U
    }
    is("b0000011".U) {
      raw.op := LOAD; raw.uses_rs1 := true.B; raw.writes_rd := true.B; raw.use_imm := true.B
      raw.imm := sext(inst(31, 20)); raw.mem_size := inst(13, 12); raw.load_signed := !inst(14)
      raw.illegal := !(f3 === 0.U || f3 === 1.U || f3 === 2.U || f3 === 4.U || f3 === 5.U)
    }
    is("b0100011".U) {
      raw.op := STORE; raw.uses_rs1 := true.B; raw.uses_rs2 := true.B; raw.use_imm := true.B
      raw.imm := sext(Cat(inst(31, 25), inst(11, 7))); raw.mem_size := inst(13, 12)
      raw.illegal := f3 > 2.U
    }
    is("b0010011".U) {
      raw.uses_rs1 := true.B; raw.writes_rd := true.B; raw.use_imm := true.B
      raw.imm := sext(inst(31, 20))
      raw.op := MuxLookup(f3, ADD)(Seq(0.U -> ADD, 2.U -> SLT, 3.U -> SLTU, 4.U -> XOR,
        6.U -> OR, 7.U -> AND, 1.U -> SLL, 5.U -> Mux(inst(30), SRA, SRL)))
      when(f3 === 1.U || f3 === 5.U) { raw.imm := inst(24, 20) }
      when(f3 === 1.U) { raw.illegal := f7 =/= 0.U }
      when(f3 === 5.U) { raw.illegal := f7 =/= 0.U && f7 =/= "b0100000".U }
    }
    is("b0110011".U) {
      raw.uses_rs1 := true.B; raw.uses_rs2 := true.B; raw.writes_rd := true.B
      when(f7 === 1.U) {
        raw.op := MuxLookup(f3, ADD)(Seq(0.U -> MUL, 1.U -> MULH, 2.U -> MULHSU, 3.U -> MULHU,
          4.U -> DIV, 5.U -> DIVU, 6.U -> REM, 7.U -> REMU))
      }.otherwise {
        raw.op := MuxLookup(f3, ADD)(Seq(0.U -> Mux(inst(30), SUB, ADD), 1.U -> SLL, 2.U -> SLT,
          3.U -> SLTU, 4.U -> XOR, 5.U -> Mux(inst(30), SRA, SRL), 6.U -> OR, 7.U -> AND))
        raw.illegal := f7 =/= 0.U && !(f7 === "b0100000".U && (f3 === 0.U || f3 === 5.U))
      }
    }
  }
  val knownOpcode = Seq(0x37, 0x17, 0x6f, 0x67, 0x63, 0x03, 0x23, 0x13, 0x33)
    .map(x => inst(6, 0) === x.U).reduce(_ || _)
  when(!knownOpcode) { raw.illegal := true.B }
  d := raw
  d.writes_rd := raw.writes_rd && raw.rd =/= 0.U
  when(raw.illegal) {
    d.uses_rs1 := false.B; d.uses_rs2 := false.B; d.writes_rd := false.B; d.use_imm := false.B
  }
  dec := d.asUInt
}
class Alu extends Logic {
  override def desiredName = "alu"
  val op = in(6); val a = in(32); val b = in(32); val pc = in(32); val imm = in(32); val result = out(32)
  val subtract = op === SUB || op === SLT || op === SLTU
  val (arithmeticValue, noBorrow) = PrefixAdder(a, b ^ Fill(32, subtract), subtract)
  val pcValue = PrefixAdder(pc, imm)._1
  result := MuxLookup(op, 0.U(32.W))(Seq(
    ADD -> arithmeticValue, SUB -> arithmeticValue, SLL -> (a << b(4, 0))(31, 0),
    SLT -> Cat(0.U(31.W), Mux(a(31) =/= b(31), a(31), !noBorrow)),
    SLTU -> Cat(0.U(31.W), !noBorrow), XOR -> (a ^ b), SRL -> (a >> b(4, 0)),
    SRA -> (a.asSInt >> b(4, 0)).asUInt, OR -> (a | b), AND -> (a & b), LUI -> imm, AUIPC -> pcValue))
}
class BranchUnit extends Logic {
  override def desiredName = "branch_unit"
  val op = in(6); val a = in(32); val b = in(32); val pc = in(32); val imm = in(32)
  val result = out(32); val next_pc = out(32); val taken = outBool(); val misaligned = outBool()
  result := pc + 4.U
  val target = Mux(op === JALR, (a + imm) & "hfffffffe".U(32.W), pc + imm)
  taken := MuxLookup(op, false.B)(Seq(JAL -> true.B, JALR -> true.B, BEQ -> (a === b), BNE -> (a =/= b),
    BLT -> (a.asSInt < b.asSInt), BGE -> (a.asSInt >= b.asSInt), BLTU -> (a < b), BGEU -> (a >= b)))
  next_pc := Mux(taken, target, result); misaligned := taken && target(1, 0) =/= 0.U
}

package firrtl
import firrtl.annotations.{ModuleTarget, SingleTargetAnnotation}

// CIRCT's supported annotation for ordinary SystemVerilog module attributes.
case class AttributeAnnotation(target: ModuleTarget, description: String)
    extends SingleTargetAnnotation[ModuleTarget] {
  override def duplicate(n: ModuleTarget): AttributeAnnotation = copy(target = n)
}
